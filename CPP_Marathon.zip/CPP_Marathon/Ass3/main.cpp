#include "patient.h"

int main()
{
    float m1[3] = {56, 76, 87};
    float m2[3] = {45, 56, 67};

    // object created
    patient p1(232, "Bob", m1);
    patient p2(332, "Bob", m2);

    // compare
    if (p1 == p2)
    {
        std::cout << "Names of patients are same" << std::endl;
        std::cout << std::endl;
    }
    else
    {
        std::cout << "Name of patients are not same" << std::endl;
        std::cout << std::endl;
    }

    //compare average sum 
    if(p1<p2){
        std::cout<<"Temperature of patient p2 is higher"<<std::endl;
        std::cout<<std::endl;
    }
    else{
        std::cout<<"Temperatur of patient 1 is higher"<<std::endl;
        std::cout<<std::endl;
    }

    // value at index
    int index = 1;
    char indexvalue = p1[index];
    std::cout << "Value at index is " << indexvalue << std::endl;
    std::cout << std::endl;
    
    //modify value at index
    std::cout<<"Name before "<<std::endl;
    std::cout<<p1.getPatientname()<<std::endl;
    p1[index]='T';
    std::cout<<"Name changed to "<<std::endl;
    std::cout<<p1.getPatientname()<<std::endl;

    // ouput
    std::cout << p1;
    std::cout << p2;
}