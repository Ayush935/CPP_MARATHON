#include "patient.h"
#include <cstring>

patient::patient() : patientnumber(10) // default constructor
{
    patientname = new char[10];
    strcpy(patientname, "John");
    temperature_values = new float[3];
    temperature_values[0] = 55;
    temperature_values[1] = 67;
    temperature_values[2] = 78;
}

patient::patient(int number, const char *name, float *temp) : patientnumber(number) // para constructor
{
    patientname = new char(strlen(name) + 1);
    strcpy(patientname, name);
    temperature_values = new float[3];
    for (int i = 0; i < 3; i++)
    {
        temperature_values[i] = temp[i];
    }
}

patient::patient(const patient &other) // copy constructor
{
    patientnumber = other.patientnumber;
    patientname = new char[strlen(other.patientname) + 1];
    strcpy(patientname, other.patientname);
    temperature_values = new float[3];
    for (int i = 0; i < 3; i++)
    {
        temperature_values[i] = other.temperature_values[i];
    }
}

float patient::calculateAvgtemperature() // calculate the average temprature
{
    float sumAvg = 0;
    for (int i = 0; i < 3; i++)
    {
        sumAvg += temperature_values[i];
    }
    sumAvg = sumAvg / 3.0;
    return sumAvg;
}

void patient::display() // member function for displaying
{
    std::cout << "Patient Name is " << std::endl;
    std::cout << patientname;
    std::cout << "Patient Number is" << std::endl;
    std::cout << patientnumber;
    std::cout << "Temperature value " << std::endl;
    for (int i = 0; i < 3; i++)
    {
        std::cout << temperature_values[i] << " ";
    }
    std::cout << std::endl;
}

bool patient::operator<(patient &p) // overloading for operator <
{
    if (calculateAvgtemperature() < p.calculateAvgtemperature())
    {
        return true;
    }
    return false;
}

bool patient::operator==(patient &p) // overloading for operator ==
{
    if (!strcmp(patientname, p.patientname))
    {
        return true;
    }
    return false;
}

char &patient::operator[](int index) // overloading for [] subscript
{   
    //patientname[index]='c';
    return patientname[index];
}


std::ostream &operator<<(std::ostream &out, patient &p) // overloading for <<
{
    out << "Patient number is " << p.patientnumber << "\n";
    out << "Patient Name is " << p.patientname << "\n";
    for (int i = 0; i < 3; i++)
    {
        out << p.temperature_values[i] << " ";
    }
    out << "\n";
    return out;
}

patient::~patient() // destructor
{
    delete patientname;
    delete[] temperature_values;
}