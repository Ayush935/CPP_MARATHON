#ifndef PATIENT_H
#define PATIENT_H

#include <iostream>

class patient
{ // data members
    int patientnumber;
    char *patientname;
    float *temperature_values;

public:
    patient();                           // default constructor
    patient(int, const char *, float *); // para constructor
    patient(const patient &other);       // copy constructor
    float calculateAvgtemperature();     // member functions
    void display();
    friend std::ostream &operator<<(std::ostream &, patient &);
    bool operator<(patient &p);
    bool operator==(patient &p);
    char &operator[](int);
   // char &operator[](char);

    ~patient();

    char *getPatientname() const { return patientname; }
};

#endif // PATIENT_H
