#ifndef FLIGHT_H
#define FLIGHT_H

#include <iostream>

class flight
{
    std::string flightnumber; // members
    double distance;
    std::string flighttype;
    double fuelquantity;
    double fare;

public:
    flight();                                 // default constructer
    flight(std::string, double, std::string); // para constructor

    // getter setter functions

    std::string getFlightnumber() const { return flightnumber; }
    void setFlightnumber(const std::string &flightnumber_) { flightnumber = flightnumber_; }

    double getDistance() const { return distance; }
    void setDistance(double distance_) { distance = distance_; }

    std::string getFlighttype() const { return flighttype; }
    void setFlighttype(const std::string &flighttype_) { flighttype = flighttype_; }

    double getFuelquantity() const { return fuelquantity; }
    void setFuelquantity(double fuelquantity_) { fuelquantity = fuelquantity_; }

    double getFare() const { return fare; }
    void setFare(double fare_) { fare = fare_; }

    // member functions

    void calculatefare();
    void calculatefuel();
    void feedinfo();
    void showinfo();
};

void searchflight(flight f[], std::string);
void maxfare(flight f[]);
#endif // FLIGHT_H
