#include "flight.h"

void searchflight(flight f[], std::string flightnames)
{ // searching the flight
    int availabe = 0;
    for (int i = 0; i < 3; i++)
    {
        if (flightnames == f[i].getFlightnumber())
        {
            availabe = 1;
        }
    }
    if (availabe == 1)
    {
        std::cout << "Flight found" << std::endl;
    }
    else
    {
        std::cout << "Flight not found" << std::endl;
    }
    std::cout << std::endl;
}

void maxfare(flight f[])
{ // searching maximum fare
    int t = 0;
    std::string s;
    for (int i = 0; i < 3; i++)
    {
        if (t < f[i].getFare())
        {
            t = f[i].getFare();
            s = f[i].getFlightnumber();
        }
    }
    std::cout << "Flight number with highest fare " << s << std::endl;
    std::cout << std::endl;
}

int main()
{
    flight f[3];
    for (int i = 0; i < 3; i++)
    {
        f[i].feedinfo();
        f[i].calculatefuel();
        f[i].calculatefare();
    }

    std::string flightnames;
    std::cin >> flightnames;
    searchflight(f, flightnames);

    maxfare(f);

    for (int i = 0; i < 3; i++)
    {
        f[i].showinfo();
    }
}