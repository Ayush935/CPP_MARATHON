#include "flight.h"

// default constructor
flight::flight() : flightnumber("AMV"), distance(1000), flighttype("ACD"), fuelquantity(10000), fare(3000) {}

// para constructor
flight::flight(std::string flightnum, double flightdist, std::string flightty) : flightnumber(flightnum), distance(flightdist), flighttype(flightty) {}

// Member function calculating fare
void flight::calculatefare()
{
  
    if (distance<= 1000)
    {
        setFare(1000);
    }
    else if (distance> 1000 && distance <= 1500)
    {
        setFare(11000);
    }
    else if (distance > 1500 && distance <= 2000)
    {
        setFare(22000);
    }
    else if (distance > 2000)
    {
        setFare(30000);
    }
}

// member function calculating fuel
void flight::calculatefuel()
{
    
    if (distance <= 1000)
    {
        setFuelquantity(4000);
    }
    else if (distance > 1000 && getDistance() <= 1500)
    {
        setFuelquantity(6000);
    }
    else if (distance > 1500 && getDistance() <= 2000)
    {
        setFuelquantity(7500);
    }
    else if (distance > 2000)
    {
        setFuelquantity(10000);
    }
}

// member function for accepting user info
void flight::feedinfo()
{
    std::cout << "For Flight " << std::endl;
    std::cout << "Flightnumber" << std::endl;
    std::cin >> flightnumber;
    std::cout << "Distance " << std::endl;
    std::cin >> distance;
    std::cout << "FlightType" << std::endl;
    std::cin >> flighttype;
    std::cout << std::endl;
}

// member function for showing info
void flight::showinfo()
{
    std::cout << "Flightnumber" << std::endl;
    std::cout << flightnumber << std::endl;
    std::cout << "Distance" << std::endl;
    std::cout << distance << std::endl;
    std::cout << "Flight Type" << std::endl;
    std::cout << flighttype << std::endl;
    std::cout << "Fuel Quantity" << std::endl;
    std::cout << fuelquantity << std::endl;
    std::cout << "Fare" << std::endl;
    std::cout << fare << std::endl;
}