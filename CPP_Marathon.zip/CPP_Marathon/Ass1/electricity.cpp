#include "electricity.h"

electricity::electricity() : sectionload(0), electricitylab(0), presentReading(0), previousReading(0), consumption(0){};

// electricity::electricity(int a,int b,long long int c,long long int d):sectionload(a),electricitylab(b),{};

void electricity::accept()
{
    std::cout << "Enter SanctionLoad: " << std::endl;
    std::cin >> sectionload;
    std::cout << "Enter electricitylab: " << std::endl;
    std::cin >> electricitylab;
    std::cout << "Enter presentReading: " << std::endl;
    std::cin >> presentReading;
    std::cout << "Enter previousReading: " << std::endl;
    std::cin >> previousReading;
    std::cout << "Enter Consumption: " << std::endl;
    std::cin >> consumption;
}

void electricity::display()
{
    std::cout << "SanctionLoad: " << sectionload << std::endl;

    std::cout << "electricitylab: " << electricitylab << std::endl;

    std::cout << "presentReading: " << presentReading << std::endl;

    std::cout << "previousReading: " << previousReading << std::endl;

    std::cout << "Consumption: " << consumption << std::endl;
}

void electricity::calculateElectricityBill(electricity p)
{
    int a = p.getSectionload();
    int b = p.getElectricitylab();
    long long int c = p.getPresentReading();
    long long int d = p.getPreviousReading();
    long long int e = p.getConsumption();
    if (c < d)
    {
        std::cout << "ElectricityBill is : " << 0 << std::endl;
    }
    else
    {
        long long int ans = (a * b) + (e * (b / 100));
        std::cout << "ElectricityBill is : " << ans << std::endl;
    }
}
