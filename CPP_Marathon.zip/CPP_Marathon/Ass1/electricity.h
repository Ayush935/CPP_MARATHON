#ifndef ELECTRICITY_H
#define ELECTRICITY_H

#include <iostream>

class electricity
{
    int sectionload;
    int electricitylab;
    long long int presentReading;
    long long int previousReading;
    long long int consumption;

public:
    electricity();
    //    electricity(int,int,long long int,long long int);

    int getSectionload() const { return sectionload; }
    void setSectionload(int sectionload_) { sectionload = sectionload_; }

    int getElectricitylab() const { return electricitylab; }
    void setElectricitylab(int electricitylab_) { electricitylab = electricitylab_; }

    long long int getPresentReading() const { return presentReading; }
    void setPresentReading(long long int presentReading_) { presentReading = presentReading_; }

    long long int getPreviousReading() const { return previousReading; }
    void setPreviousReading(long long int previousReading_) { previousReading = previousReading_; }

    long long int getConsumption() const { return consumption; }
    void setConsumption(long long int consumption_) { consumption = consumption_; }

    void accept();
    void display();
    void calculateElectricityBill(electricity p);
};



#endif // ELECTRICITY_H
