#include "electricity.h"


int main()
{

    electricity p;
    p.accept();
    p.calculateElectricityBill(p);
    p.display();
}